"use strict";

const ouraEffort = require("..");

describe("fitbit-effort", () => {
  it("needs tests");
});
