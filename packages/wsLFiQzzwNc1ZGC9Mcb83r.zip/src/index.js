/**
 * Entrypoint of the Remote Component.
 */

import FitbitEffort from "./FitbitEffort.js";
export default FitbitEffort;
