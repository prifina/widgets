# `fitbit-effort`

> TODO: description

## Usage

```
const ouraEffort = require('fitbit-effort');

// TODO: DEMONSTRATE API
```
