"use strict";

const fitbitActivity = require("..");

describe("fitbit-activity", () => {
  it("needs tests");
});
