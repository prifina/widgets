# `fitbit-activity`

> TODO: description

## Usage

```
const ouraActivity = require('fitbit-activity');

// TODO: DEMONSTRATE API
```
