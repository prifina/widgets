/**
 * Entrypoint of the Remote Component.
 */

import FitbitActivity from "./FitbitActivity.js";
export default FitbitActivity;
