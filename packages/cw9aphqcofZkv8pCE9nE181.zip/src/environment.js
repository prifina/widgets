const APP_ID = process.env.REACT_APP_ID;
const APP_VERSION = process.env.REACT_APP_VERSION;
const DEBUG = process.env.DEBUG;

export {
	APP_ID,
	APP_VERSION,
	DEBUG
};