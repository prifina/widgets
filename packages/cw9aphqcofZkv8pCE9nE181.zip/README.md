# `dataTest`

> TODO: description

## Usage

```
const dataTest = require('dataTest');

// TODO: DEMONSTRATE API
```
