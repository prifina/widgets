'use strict';

const dataTest = require('..');

describe('dataTest', () => {
    it('needs tests');
});
