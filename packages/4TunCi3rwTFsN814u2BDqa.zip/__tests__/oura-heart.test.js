"use strict";

const ouraHeart = require("..");

describe("oura-heart", () => {
  it("needs tests");
});
