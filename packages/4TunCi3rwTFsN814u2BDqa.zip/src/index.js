/**
 * Entrypoint of the Remote Component.
 */

import OuraHeart from "./OuraHeart.js";
export default OuraHeart;
