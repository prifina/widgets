/**
 * Entrypoint of the Remote Component.
 */

import FitbitHeart from "./FitbitHeart.js";
export default FitbitHeart;
