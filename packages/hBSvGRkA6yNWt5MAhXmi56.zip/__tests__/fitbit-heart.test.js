"use strict";

const ouraHeart = require("..");

describe("fitbit-heart", () => {
  it("needs tests");
});
