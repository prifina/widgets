/**
 * Entrypoint of the Remote Component.
 */

import OuraEffort from "./OuraEffort.js";
export default OuraEffort;
