# `oura-effort`

> TODO: description

## Usage

```
const ouraEffort = require('oura-effort');

// TODO: DEMONSTRATE API
```
