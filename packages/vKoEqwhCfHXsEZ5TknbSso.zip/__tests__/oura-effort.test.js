"use strict";

const ouraEffort = require("..");

describe("oura-effort", () => {
  it("needs tests");
});
