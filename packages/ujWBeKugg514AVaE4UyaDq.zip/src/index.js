/**
 * Entrypoint of the Remote Component.
 */
 import AvatarWidget from "./AvatarWidget";

 export default AvatarWidget;
 