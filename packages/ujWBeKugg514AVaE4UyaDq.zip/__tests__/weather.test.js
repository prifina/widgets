'use strict';

const avatarWidget = require('..');

describe('avatar-widget', () => {
    it('needs tests');
});
