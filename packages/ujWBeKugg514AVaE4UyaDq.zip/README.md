# `avatar-widget`

> TODO: description

## Usage

```
const avatar-widget = require('avatar-widget');

// TODO: DEMONSTRATE API
```
