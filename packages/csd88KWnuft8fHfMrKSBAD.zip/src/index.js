/**
 * Entrypoint of the Remote Component.
 */

import OuraActivity from "./OuraActivity.js";
export default OuraActivity;
