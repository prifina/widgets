"use strict";

const ouraActivity = require("..");

describe("oura-activity", () => {
  it("needs tests");
});
