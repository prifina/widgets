/**
 * Entrypoint of the Remote Component.
 */

import FitbitSleep from "./FitbitSleep.js";
export default FitbitSleep;
