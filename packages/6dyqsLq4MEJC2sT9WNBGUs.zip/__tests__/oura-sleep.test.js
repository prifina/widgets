'use strict';

const ouraSleep = require('..');

describe('oura-sleep', () => {
    it('needs tests');
});
