/**
 * Entrypoint of the Remote Component.
 */

import OuraSleep from "./OuraSleep.js";
export default OuraSleep;
